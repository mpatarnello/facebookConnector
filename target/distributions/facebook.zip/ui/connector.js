$.foxweave.addComponentView(function() {

});
